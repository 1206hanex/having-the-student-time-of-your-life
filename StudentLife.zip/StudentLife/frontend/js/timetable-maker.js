const timetable = document.getElementById("timetable");

const days = ["Mon", "Tue", "Wed", "Thu", "Fri"];
const startHour = 8;
const endHour = 20;

// Create top header row
timetable.innerHTML += `<div class="time-label"></div>`;
days.forEach(day => {
  timetable.innerHTML += `<div class="day-label">${day}</div>`;
});

// Create each hour row
for (let hour = startHour; hour < endHour; hour++) {
  const hourLabel = hour < 12 ? `${hour} AM`
                  : hour === 12 ? `12 PM`
                  : `${hour - 12} PM`;

  timetable.innerHTML += `<div class="time-label">${hourLabel}</div>`;

  days.forEach(day => {
    timetable.innerHTML += `<div class="cell" data-day="${day}" data-time="${hour}"></div>`;
  });
}

function addClassToTimetable({ name, day, time }) {
  const cell = document.querySelector(`.cell[data-day="${day}"][data-time="${time}"]`);
  if (!cell) return;

  const block = document.createElement("div");
  block.classList.add("class-block");

  const label = document.createElement("span");
  label.textContent = name;

  const close = document.createElement("div");
  close.classList.add("close-btn");
  close.textContent = "×";
  close.onclick = () => {
    block.remove();
    addToRemovedList({ name, day, time });
  };

  block.appendChild(label);
  block.appendChild(close);
  cell.appendChild(block);
}

function addToRemovedList(classData) {
  const container = document.getElementById("removed-classes");

  const block = document.createElement("div");
  block.classList.add("class-block", "removed-block");
  block.textContent = classData.name;

  block.onclick = () => {
    block.remove();
    addClassToTimetable(classData);
  };

  container.appendChild(block);
}




function handleAddCustomClass() {
  const name = document.getElementById("custom-name").value.trim();
  const day = document.getElementById("custom-day").value;
  const time = parseInt(document.getElementById("custom-time").value);

  if (!name || !day || isNaN(time)) {
    alert("Please fill out all fields.");
    return;
  }

  addClassToTimetable({ name, day, time });

  // Clear the form
  document.getElementById("custom-name").value = "";
  document.getElementById("custom-day").value = "";
  document.getElementById("custom-time").value = "";
}
