const timetable = document.getElementById("timetable");

const days = ["Mon", "Tue", "Wed", "Thu", "Fri"];
const startHour = 8;
const endHour = 20;

// Create top header row
timetable.innerHTML += `<div class="time-label"></div>`;
days.forEach(day => {
  timetable.innerHTML += `<div class="day-label">${day}</div>`;
});

// Create each hour row
for (let hour = startHour; hour < endHour; hour++) {
  const hourLabel = hour < 12 ? `${hour} AM`
                  : hour === 12 ? `12 PM`
                  : `${hour - 12} PM`;

  timetable.innerHTML += `<div class="time-label">${hourLabel}</div>`;

  days.forEach(day => {
    timetable.innerHTML += `<div class="cell" data-day="${day}" data-time="${hour}"></div>`;
  });
}



fetch("http://localhost:3000/api/timetable", {
  method: "GET",
  credentials: "include" 
})
  .then(res => res.json())
  .then(data => {
    data.forEach(entry => {
      const hour = parseInt(entry.start_time.split(":")[0]);
      const day = entry.day;

      
      if (!entry.is_active) {
        addToRemovedList({ name: entry.name, day: day, time: hour });
      } else {
        addClassToTimetable({ name: entry.name, day: day, time: hour });
      }
    });
  })
  .catch(err => {
    console.error('Failed to load timetable:', err);
  });


function addClassToTimetable({ name, day, time }) {
  const cell = document.querySelector(`.cell[data-day="${day}"][data-time="${time}"]`);
  if (!cell) return;

  const block = document.createElement("div");
  block.classList.add("class-block");

  const label = document.createElement("span");
  label.textContent = name;

  const close = document.createElement("div");
  close.classList.add("close-btn");
  close.textContent = "×";
  close.onclick = () => {
    block.remove();
    addToRemovedList({ name, day, time });



    fetch("http://localhost:3000/api/timetable/update-active", {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, day, time, is_active: 0 })
  }).catch(err => console.error("Failed to deactivate class", err));
  };

  block.appendChild(label);
  block.appendChild(close);
  cell.appendChild(block);
}

function addToRemovedList(classData) {
  const container = document.getElementById("removed-classes");

  const block = document.createElement("div");
  block.classList.add("class-block", "removed-block");
  block.textContent = classData.name;

  block.onclick = () => {
    block.remove();
    addClassToTimetable(classData);



    fetch("http://localhost:3000/api/timetable/update-active", {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ...classData, is_active: 1 })
  }).catch(err => console.error("Failed to reactivate class", err));
  };

  container.appendChild(block);
}




function handleAddCustomClass() {
  const name = document.getElementById("custom-name").value.trim();
  const day = document.getElementById("custom-day").value;
  const time = parseInt(document.getElementById("custom-time").value);

  if (!name || !day || isNaN(time)) {
    alert("Please fill out all fields.");
    return;
  }

  addClassToTimetable({ name, day, time });

  fetch("http://localhost:3000/api/timetable/add", {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, day, time })
  }).catch(err => console.error("Add failed", err));


  // Clear the form
  document.getElementById("custom-name").value = "";
  document.getElementById("custom-day").value = "";
  document.getElementById("custom-time").value = "";
}
