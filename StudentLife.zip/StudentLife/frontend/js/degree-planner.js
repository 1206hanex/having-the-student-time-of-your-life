const plannerContainer = document.getElementById('planner-container');

const years = [1, 2, 3, 4];
years.forEach(year => {
  const yearDiv = document.createElement('div');
  yearDiv.classList.add('year-block');
  yearDiv.innerHTML = `<h3>Year ${year}</h3>`;

  ['Semester 1', 'Semester 2'].forEach((sem, i) => {
    const semDiv = document.createElement('div');
    semDiv.classList.add('semester-block');

    const paperList = document.createElement('ul');
    paperList.classList.add('paper-list');

    const input = document.createElement('input');
    input.placeholder = 'Add paper name';
    input.type = 'text';

    const button = document.createElement('button');
    button.textContent = 'Add';
    button.onclick = () => {
      if (input.value.trim()) {
        const li = document.createElement('li');
        li.textContent = input.value.trim();
        paperList.appendChild(li);
        input.value = '';
      }
    };

    semDiv.innerHTML = `<h4>${sem}</h4>`;
    semDiv.appendChild(input);
    semDiv.appendChild(button);
    semDiv.appendChild(paperList);

    yearDiv.appendChild(semDiv);
  });

  plannerContainer.appendChild(yearDiv);
});
