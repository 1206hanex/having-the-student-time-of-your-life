const plannerContainer = document.getElementById('planner-container');

// define year ranges based on pid 
const yearBoundaries = {
  1: [1, 8],
  2: [9, 17],
  3: [18, 26],
  4: [27, 32]
};

// Map paper_type to class color
const typeToColor = {
  'COMPULSORY': 'green',
  'STREAM': 'orange',
  'ELECTIVE': 'blue',
  'PLACEMENT': 'red'
};

fetch('http://localhost:3000/api/papers')
  .then(res => res.json())
  .then(data => {
    Object.entries(yearBoundaries).forEach(([year, [start, end]]) => {
      const yearDiv = document.createElement('div');
      yearDiv.classList.add('year-row');

      const label = document.createElement('div');
      label.classList.add('year-label');
      label.textContent = `Year ${year}`;
      yearDiv.appendChild(label);

      const papersDiv = document.createElement('div');
      papersDiv.classList.add('papers');

      data.filter(p => p.pid >= start && p.pid <= end).forEach(paper => {
        const div = document.createElement('div');
        div.classList.add('paper', typeToColor[paper.paper_type]);
        div.textContent = paper.paper_code;
        papersDiv.appendChild(div);
      });

      yearDiv.appendChild(papersDiv);
      plannerContainer.appendChild(yearDiv);
    });
  })
  .catch(err => {
    console.error('Failed to load papers:', err);
  });
