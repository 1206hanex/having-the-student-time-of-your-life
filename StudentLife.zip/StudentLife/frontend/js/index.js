fetch('http://localhost:3000/timetable')
  .then(response => response.json())
  .then(data => {
    const container = document.getElementById('timetable');

    data.forEach(item => {
      const div = document.createElement('div');
      div.className = 'timetable-item';
      div.innerHTML = `
        <strong>${item.name}</strong><br>
        ${item.day} | ${item.start_time} - ${item.end_time}<br>
        Location: ${item.description}
      `;
      container.appendChild(div);
    });
  })
  .catch(err => {
    console.error('Failed to load timetable:', err);
  });
