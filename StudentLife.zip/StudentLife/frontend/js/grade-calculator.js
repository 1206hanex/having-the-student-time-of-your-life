function openExpandedView(title, grade) {
  document.getElementById('widget-container').style.display = 'none';
  document.getElementById('expanded-title').textContent = title;
  document.getElementById('expanded-grade').textContent = `Current Grade: ${grade}`;
  document.getElementById('overlay').style.display = 'flex';
}

function closeExpandedView() {
  document.getElementById('overlay').style.display = 'none';
  document.getElementById('widget-container').style.display = 'flex';
}

function handleOverlayClick(event) {
  // Only close if the click target is the overlay itself (outside the content box)
  if (event.target.id === 'overlay') {
    closeExpandedView();
  }
}
