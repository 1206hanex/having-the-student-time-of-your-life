document.getElementById('loginForm')?.addEventListener('submit', function (e) {
  e.preventDefault();
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;

  // Simulated credentials check
  if (username === 'admin' && password === '1234') {
    window.location.href = 'pages/index.html';
  } else {
    alert('Invalid username or password');
  }
});
 