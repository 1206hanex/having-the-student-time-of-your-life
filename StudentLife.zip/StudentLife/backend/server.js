const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');

const app = express();
const port = 3000;


const session = require('express-session');





// Middleware
app.use(cors({
  origin: 'http://localhost',
  credentials: true
}));
app.use(express.json());

app.use(session({
  secret: '1234', 
  resave: false,
  saveUninitialized: true,
}));

// MySQL connection setup
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'student_tools'
});

// Connect to MySQL
db.connect((err) => {
  if (err) {
    console.error('MySQL connection failed:', err);
  } else {
    console.log('Connected to MySQL');
  }
});


app.get('/api/timetable', (req, res) => {
  console.log(req.session.userId);
  db.query(
    'SELECT name, day, start_time, end_time, description, is_active FROM user_timetable WHERE uid = ?',
    [req.session.userId], 
    (err, results) => {
      if (err) {
        res.status(500).json({ error: 'DB error' });
      } else {
        res.json(results);
      }
    }
  );
});


app.post('/api/timetable/add', (req, res) => {


  console.log(req.body);



  const { name, day, time } = req.body;
  const uid = req.session.userId;

  if (!uid) return res.status(401).json({ error: "Not logged in" });

  const start_time = `${String(time).padStart(2, '0')}:00:00`;
  const end_time = `${String(time + 1).padStart(2, '0')}:00:00`;

  db.query(
    "INSERT INTO user_timetable (uid, name, day, start_time, end_time, is_active, description) VALUES (?, ?, ?, ?, ?, 1, '')",
    [uid, name, day, start_time, end_time],
    (err) => {
      if (err) return res.status(500).json({ error: "Insert failed" });
      res.json({ message: "Class added" });
    }
  );
});



app.post('/api/timetable/update-active', (req, res) => {

  
  console.log(req.body);



  const { name, day, time, is_active } = req.body;
  const uid = req.session.userId;

  //weird error, but the time only got sent for the double digit times
  //it broke for the 8 and 9am times, so they need to be padded
  const paddedTime = String(time).padStart(2, '0');


  if (!uid) return res.status(401).json({ error: "Not logged in" });

  db.query(
    "UPDATE user_timetable SET is_active = ? WHERE uid = ? AND name = ? AND day = ? AND start_time LIKE ?",
    [is_active, uid, name, day, `${paddedTime}%`],
    (err) => {
      if (err) return res.status(500).json({ error: "Update failed" });
      res.json({ message: "Status updated" });
    }
  );
});



app.get('/api/papers', (req, res) => {
  db.query('SELECT * FROM papers ORDER BY pid ASC', (err, results) => {
    if (err) return res.status(500).json({ error: err });
    res.json(results);
  });
});


app.post("/api/login", (req, res) => {
  const { username, password } = req.body;

  db.query("SELECT * FROM users WHERE username = ?", [username], (err, results) => {
    if (err) return res.status(500).json({ message: "Server error" });
    if (results.length === 0) return res.status(401).json({ message: "User not found" });

    const user = results[0];

    if (password === user.password) {
      req.session.userId = user.uid;

      console.log(req.session.userId);

      return res.json({ message: "Login successful" });
    } else {
      return res.status(401).json({ message: "Incorrect password" });
    }
  });
});


app.get("/api/loggedin", (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ message: "Not logged in" });
  }
  res.json({ uid: req.session.userId });
});




app.post("/api/create-account", (req, res) => {
  const { username, password } = req.body;

  db.query("SELECT * FROM users WHERE username = ?", [username], (err, results) => {
    if (err) return res.status(500).json({ message: "Server error" });
    if (results.length !== 0) {
      return res.status(401).json({ message: "Account exists with this username already" });
    }

    db.query("INSERT INTO users (username, password) VALUES (?, ?)", [username, password], (err, result) => {
      if (err) return res.status(500).json({ message: "Error creating account" });

      return res.status(201).json({ message: "Account created successfully" });
    });
  });
});


app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
