const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');

const app = express();
const port = 3000;


const session = require('express-session');

app.use(session({
  secret: '1234', 
  resave: false,
  saveUninitialized: true,
}));



// Middleware
app.use(cors());
app.use(express.json());

// MySQL connection setup
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',        // change if needed
  password: '',        // change if you have a password
  database: 'student_tools'   // replace with your database name
});

// Connect to MySQL
db.connect((err) => {
  if (err) {
    console.error('MySQL connection failed:', err);
  } else {
    console.log('Connected to MySQL');
  }
});


app.get('/timetable', (req, res) => {
  db.query(
    'SELECT name, day, start_time, end_time, description FROM user_timetable WHERE uid = ? AND is_active = 1',
    [1], // or req.query.uid if dynamic
    (err, results) => {
      if (err) {
        res.status(500).json({ error: 'DB error' });
      } else {
        res.json(results);
      }
    }
  );
});

app.get('/api/papers', (req, res) => {
  db.query('SELECT * FROM papers ORDER BY pid ASC', (err, results) => {
    if (err) return res.status(500).json({ error: err });
    res.json(results);
  });
});


app.post("/login", (req, res) => {
  const { username, password } = req.body;

  db.query("SELECT * FROM users WHERE username = ?", [username], (err, results) => {
    if (err) return res.status(500).json({ message: "Server error" });
    if (results.length === 0) return res.status(401).json({ message: "User not found" });

    const user = results[0];

    if (password === user.password) {
      req.session.userId = user.uid;
      return res.json({ message: "Login successful" });
    } else {
      return res.status(401).json({ message: "Incorrect password" });
    }
  });
});


app.get("/api/loggedin", (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ message: "Not logged in" });
  }
  res.json({ uid: req.session.userId });
});



app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
