const express = require('express');
const app = express();
const timetableRoute = require('./routes/timetable');
const gradesRoute = require('./routes/grades');
const userRoute = require('./routes/user');
const connectDB = require('./routes/mysqldb');

//define a port 
const PORT = 3000; 

app.use(express.json());

connectDB();

//use the timetable route 
app.use('/api/timetable', timetableRoute);

//use the grades routes 
app.use('/api/grades', gradesRoute);

//use the user route 
app.use('/api/user', userRoute);


app.use('api/mysqldb', connectDB);
  

//start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
