const { 
    calculateCurrentGrade, 
    calculateProjectedGrade, 
    convertToLetterGrade, 
    convertToGPA 
} = require('../utils/gradeUtils');

const db = require('mysqldb');

const calculateGrades = async (req, res) => {
    const { uid, className } = req.body;

    if(!uid || !className){
        return res.status(400).json({error: "Missing user id or class name"});
    }

    try{
        //get the weights and grades for assignments from the database 
        const[assignments] = await db.promise().query(
            'SELECT grade, weight FROM user_assignments WHERE uid = ? AND class = ?',
            [uid, className]
        );

        if (!assignments || !assignments.length == 0) {
            return res.status(400).json({ error: 'Invalid or missing assignments' });
        }

        const graded = assignments.filter(a => a.grade !== null);
        const ungraded = assignments.filter(a => a.grade === null);

        const currentScore = calculateCurrentGrade(graded);
        const projectedScore = calculateProjectedGrade(graded, ungraded);

        return res.json({
            currentScore: parseFloat(currentScore.toFixed(2)),
            currentLetter: convertToLetterGrade(currentScore),
            currentGPA: convertToGPA(currentScore),
            projectedScore: parseFloat(projectedScore.toFixed(2)),
            projectedLetter: convertToLetterGrade(projectedScore),
            projectedGPA: convertToGPA(projectedScore)
        });


    } catch (err){
        console.error(err);
        return res.status(500).json({error: 'Internal server error'});
    }
  
};


module.exports = { calculateGrades };