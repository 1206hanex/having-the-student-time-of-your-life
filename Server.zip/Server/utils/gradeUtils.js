function calculateCurrentGrade(assignments) {
    let totalScore = 0;
    let totalWeight = 0;

    assignments.forEach(assignment => {
        if(assignment.grade != null && assignment.weight != null){
            totalScore += (assignment.grade * assignment.weight)/ 100;
            totalWeight += assignment.weight; 
        }
    });

    if (totalWeight == 0) return 0;
    return (totalScore / totalWeight)* 100;

}

function calculateProjectedGrade(assignments) {
    let currentScore = 0;
    let currentWeight = 0;
    let remainingWeight = 0;

    assignments.forEach(assignment => {
        if (assignment.grade != null && assignment.weight != null) {
            currentScore += (assignment.grade * assignment.weight) / 100;
            currentWeight += assignment.weight;
        } else if (assignment.grade == null && assignment.weight != null) {
            remainingWeight += assignment.weight;
        }
    });

    if (currentWeight === 0) return 0;

    const currentAverage = currentScore / currentWeight; 
    const projectedTotal = currentScore + (currentAverage * remainingWeight);
    const totalWeight = currentWeight + remainingWeight;

    return (projectedTotal / totalWeight) * 100;
}

function convertToLetterGrade(score) {
    if (score >= 95) return 'A+';
    if (score >= 90) return 'A+';
    if (score >= 85) return 'A';
    if (score >= 80) return 'A-';
    if (score >= 75) return 'B+';
    if (score >= 70) return 'B';
    if (score >= 65) return 'B-';
    if (score >= 60) return 'C+';
    if (score >= 55) return 'C';
    if (score >= 50) return 'C-';
    if (score >= 45) return 'D';
    if (score >= 40) return 'D';
    return 'E';
}

function convertToGPA(score){
    if (score >= 95) return 9;
    if (score >= 90) return 9;
    if (score >= 85) return 8;
    if (score >= 80) return 7;
    if (score >= 75) return 6;
    if (score >= 70) return 5;
    if (score >= 65) return 4;
    if (score >= 60) return 3;
    if (score >= 55) return 2;
    if (score >= 50) return 1;
    if (score >= 40) return 0;
    return 0;
}

module.exports = { calculateCurrentGrade, calculateProjectedGrade, convertToLetterGrade, convertToGPA};