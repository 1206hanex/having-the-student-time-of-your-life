const express = require('express');
const router = express.Router();
const gradesController = require('../controllers/gradesController');

// get all grades or grades for a paper
router.get('/:paperCode', gradesController.getGradesByPaper);

// post new grades or update existing
router.post('/', gradesController.postGrades);

module.exports = router;


