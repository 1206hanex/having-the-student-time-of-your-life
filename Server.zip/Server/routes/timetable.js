const express = require('express');
const router = express.Router();

//example timetable data for now (will change to actual data)
const timetable = [
  { subject: 'COMPX101', type: 'Lecture', day: 'Monday', time: '10:00AM', room: 'MSB.1.03' },
  { subject: 'ENGEN180', type: 'Lab', day: 'Wednesday', time: '1:00PM', room: 'C.D.04' },
  { subject: 'MATHS102', type: 'Tutorial', day: 'Friday', time: '11:00AM', room: 'S.1.02' }
];

//get current timetable 
router.get('/', (req, res) => {
  res.json(timetable);
});

//post a custom timetable entry 
router.post('/', (req, res) => {
  const newEntry = req.body;
  users.push(newEntry);
  res.status(201).json({message: 'Entry added', entry: newEntry});

});

module.exports = router;