// insert this mapping at the top
const typeClass = {
  COMPULSORY: "compulsory",
  STREAM: "stream",
  PLACEMENT: "placement",
  ELECTIVE_1: "elective",
  ELECTIVE_MATHS: "elective",
  ELECTIVE_COMPUTING: "elective",
  ELECTIVE_3: "elective",
  ELECTIVE_4: "elective",
  STREAM_ELECTIVE: "stream",
};

const selectedPapers = new Set();  // track selected paper codes

document.addEventListener("DOMContentLoaded", () => {
  const loadingOverlay = document.getElementById("loading-overlay");
  const container = document.getElementById("select-widget-container");

  const widget = document.createElement("div");
  widget.className = "widget";
  widget.textContent = "Select Papers";

  const modal = document.createElement("div");
  modal.className = "modal hidden";
  modal.innerHTML = `
    <div class="modal-content">
      <span class="close-btn">&times;</span>
      <h2>Select your papers for this semester</h2>
      <p>Don't know what papers you are taking?</p>      
      <a href="degree-planner.html">Go to Degree Planner</a><br>
      <div id="paper-list"></div>
      <button id="submit-papers-btn">Confirm Selection</button> 
    </div>
  `;

  modal.querySelector("#submit-papers-btn").onclick = () => {
    loadingOverlay.classList.add("show");
    fetch("http://localhost:3000/api/papers/activate", {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ selected: Array.from(selectedPapers) }),
    })
    .then(res => {
      if (!res.ok) throw new Error("Failed to activate papers");

      return fetch("http://localhost:3000/api/scrape/run", {
        method: "GET",
        credentials: "include"
      });
    })
    .then(res => {
      if (!res.ok) throw new Error("Scraping failed");
      return res.json();
    })
    .then(data => {
      console.log("Scrape response:", data);
      modal.classList.add("hidden");
      alert("Scraping complete. Timetable and grade info loaded!");
    })
    .catch(err => {
      console.error("Activation error:", err);
      alert("Failed to activate or scrape.");
    })
    .finally(() => {
      loadingOverlay.classList.remove("show");
    });
  };

  container.appendChild(widget);
  document.body.appendChild(modal);

  widget.onclick = () => {
    modal.classList.remove("hidden");

    const paperList = document.getElementById("paper-list");
    paperList.innerHTML = "Loading...";

    fetch("http://localhost:3000/api/papers", { credentials: "include" })
      .then(res => res.json())
      .then(papers => {
        paperList.innerHTML = "";

        const grouped = { 1: [], 2: [], 3: [], 4: [] };
        papers.forEach(p => {
          if (grouped[p.year]) grouped[p.year].push(p);
        });

        for (let year = 1; year <= 4; year++) {
          if (grouped[year].length === 0) continue;

          const row = document.createElement("div");
          row.className = "planner-row";

          const heading = document.createElement("h3");
          heading.textContent = `Year ${year}`;
          row.appendChild(heading);

          const paperRow = document.createElement("div");
          paperRow.className = "paper-row";

          grouped[year].forEach(paper => {
            const paperBox = document.createElement("div");
            paperBox.className = `paper-box ${typeClass[paper.paper_type] || "default"}`;
            paperBox.textContent = paper.paper_code;

            //modify existing paperBox.onclick:
            paperBox.onclick = () => {
              const code = paper.paper_code;
              console.log("Clicked", code);
              if (selectedPapers.has(code)) {
                selectedPapers.delete(code);
                paperBox.classList.remove("selected");
              } else {
                selectedPapers.add(code);
                paperBox.classList.add("selected");
              }
            };

            paperRow.appendChild(paperBox);
          });

          row.appendChild(paperRow);
          paperList.appendChild(row);
        }
      })
      .catch(err => {
        console.error("Failed to fetch papers:", err);
        paperList.innerHTML = "<p style='color:red;'>Failed to load papers.</p>";
      });
  };

  modal.querySelector(".close-btn").onclick = () =>
    modal.classList.add("hidden");

  modal.onclick = (e) => {
    if (e.target === modal) modal.classList.add("hidden");
  };
});
