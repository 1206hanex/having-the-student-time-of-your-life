const puppeteer = require('puppeteer');

(async () => {
    try{
        //open the uni web engineering (bHongs) page
        const browser = await puppeteer.launch({ headless: false }); // change to true later
        const page = await browser.newPage();

        const selectedSubject = "Software Engineering"; //change with a grab from the db later

        const degreeUrl = 'https://www.waikato.ac.nz/study/qualifications/bachelor-of-engineering-with-honours'; //just engineering for now
        await page.goto(degreeUrl, { waitUntil: 'networkidle2' });
        console.log('Degree page loaded.');

        // scroll down a bit so we can see the dropdown area (cause we are now doing baby steps)
        await page.evaluate(() => window.scrollBy(0, 3400)); // scrolls down 3400px
        
        //can we click the button? lets find the fuck out (context, this is like the 9th time trying to get pupeteer to click a single button)
        //ok the issue is with locating the button 

        //finding the button
        await new Promise(r => setTimeout(r, 5000));    
        const buttons = await page.$$eval('button', nodes => nodes.map(n => n.innerText));

        const button = Array.from(document.querySelectorAll('button'));
        const match = button.find(b => b.innerText.trim() === 'Choose a subject');
        if (match == null) {
            console.log("button not found");
        } else {
            console.log(match);
        };

        //console.log(buttons);
        
        //button is found, and exsists, now we gotta click it. which is the next big issue
        //await page.waitForSelector('button.select-dropdown__button', { visible: true });


        // if (found) {
        //     //actully clicking the button
        //     console.log('Found the button:', found);
        //     //THIS is the issue, the button is there, but aperently its also not? like the click doesnt work because it cant locate the target, 
        //     await page.click('button.select-dropdown__button');
        //     console.log('Clicked the button!');
        // } else {
        //     console.log('Button not found.');
        // }

        // lil pause
        await new Promise(r => setTimeout(r, 5000));

        await browser.close();
    }catch (error) {
		console.error('Failed at something, idk:', error);
    }


})();

//as you can see, i have gone mad in the creation of this script. cause unlike the course scraping which just needs to read stuff, this one needs to click on a button which both aperently exists and also doesnt
//i havnt even gotten to the main function of this program which is to get the info, im just stuck on telling the program to click a sign dropdown button






//2
//copy the widgit of one class/square
//with class name, description, points and the year it is in
//save it to the db

//3
